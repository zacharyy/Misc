//**************************
// Filename: game.cpp
// Author: Aaron Rogers
// Updated: 09/04/02
// Purpose: Tic Tac Toe game
//**************************

// Library Includes
#include "game.h"


// -- Graphics --
//  Backgrounds 
#include "gfx/ham_tut.map.c"	    // gfx2gba -fsrc -m -pham_tut.pal -t8 ham_tut.bmp
#include "gfx/ham_tut.pal.c"
#include "gfx/ham_tut.raw.c"
#include "gfx/tictactoe.map.c"	    // gfx2gba -fsrc -m -ptictactoe.pal -t8 tictactoe.bmp
#include "gfx/tictactoe.pal.c"
#include "gfx/tictactoe.raw.c"
#include "gfx/game_options.map.c"	    // gfx2gba -fsrc -m -pgame_options.pal -t8 game_options.bmp
#include "gfx/game_options.pal.c"
#include "gfx/game_options.raw.c"
#include "gfx/board_240_160.map.c"	// gfx2gba -fsrc -m -pboard_240_160.pal -t8 board_240_160.bmp
#include "gfx/board_240_160.pal.c"
#include "gfx/board_240_160.raw.c"
#include "gfx/fin_p1.map.c"	    // gfx2gba -fsrc -m -pfin_p1.pal -t8 fin_p1.bmp
#include "gfx/fin_p1.pal.c"
#include "gfx/fin_p1.raw.c"
#include "gfx/fin_p2.map.c"	    // gfx2gba -fsrc -m -pfin_p2.pal -t8 fin_p2.bmp
#include "gfx/fin_p2.pal.c"
#include "gfx/fin_p2.raw.c"
#include "gfx/fin_tie.map.c"	    // gfx2gba -fsrc -m -pfin_tie.pal -t8 fin_tie.bmp
#include "gfx/fin_tie.pal.c"
#include "gfx/fin_tie.raw.c"

//  Sprites 
#include "gfx/objects.pal.c" // Generated (separately) from all of the sprites
#include "gfx/red_O_32_32.raw.c" // gfx2gba -D -fsrc -t8 red_O_32_32.bmp
#include "gfx/red_X_32_32.raw.c"
#include "gfx/blue_O_32_32.raw.c" // gfx2gba -D -fsrc -t8 blue_O_32_32.bmp
#include "gfx/blue_X_32_32.raw.c"

#include "gfx/objects_ms.pal.c" // Generated (separately) from all of the sprites
#include "gfx/numbers.raw.c" // gfx2gba -D -fsrc -t8 numbers.bmp


//*********************************
// Function: TICTACTOE::TICTACTOE()
// Purpose: Default Constructor
//*********************************
TICTACTOE::TICTACTOE()
{
	// Set the game state to START
	game_state = START;

	// Initialize all of the spots
	// 0 = empty, 1 = Player 1, 2 = Player 2
	for (int i = 0; i < 9; ++i) {
		board[i] = 0; // Every space is empty at first
	}	

	// Set the number of players to 1
	players = 1;

	// Set the skill level to 3
	skill = 3;

	// Setup the mixer for sound
	mixer_freq = 26757;

}  // End of TICTACTOE::TICTACTOE()


//*****************************
// Function: TICTACTOE::init()
// Purpose: Initialize the game
//*****************************
void TICTACTOE::init()
{
	// Initialize HAMlib
	ham_Init();
	
	// Setup the background mode
	ham_SetBgMode(1);


	return;
} // End of TICTACTOE::init()


//*****************************************
// Function: TICTACTOE::start_screen_init()
// Purpose: Initialize the start screen
//*****************************************
void TICTACTOE::start_screen_init()
{

	// Initalize the sound mixing
	ham_InitMixer(mixer_freq);

	// Set up the sounds
	mysample[0] =  ham_InitSample((u8*)_binary_clip_raw_start.data,
		_binary_clip_raw_start.size,
		_binary_clip_raw_start.freq>>10);
	mysample[1] =  ham_InitSample((u8*)_binary_dong_raw_start.data,
		_binary_dong_raw_start.size,
		_binary_dong_raw_start.freq>>10);

	// Start the VBL counter at 0
	vbl_count = 0;

	// Start with the first start screen image
	start_screen_slide = 0;

	// Show the HAM Tutorial logo
	// Initialize the background palette
	ham_LoadBGPal((void *)SplashScreen_Palette,256);

	// Setup the tileset for our image
	ham_bg[0].ti = ham_InitTileSet((void *)SplashScreen_Tiles,
		SIZEOF_16BIT(SplashScreen_Tiles),1,1);
	
	// Setup the map for our image
	ham_bg[0].mi = ham_InitMapEmptySet(3,0);
	bg_one = ham_InitMapFragment((void *)SplashScreen_Map,30,20,0,0,30,20,0);
	ham_InsertMapFragment(bg_one,0,0,0);
	
	// Display the background
	ham_InitBg(0,1,0,0);

	return;
} // End of TICTACTOE::start_screen_init()


//***********************************************
// Function: TICTACTOE::start_screen_query_keys()
// Purpose: Gets input during start_screen()
//***********************************************
void TICTACTOE::start_screen_query_keys()
{
	// Increment the VBL counter every VBL
	++vbl_count;

	/*if ((vbl_count > 50) && (start_screen_slide == 0)) {
		vbl_count = 0;
		start_screen_slide = 1;

		// Deinitialize the background and sprites
		ham_DeInitBg(0);

		// Show the TICTACTOE screen

		// Initialize the background and sprites palettes
		ham_LoadBGPal((void *)tictactoe_Palette,256);

		// Setup the tileset for our image
		ham_bg[0].ti = ham_InitTileSet((void *)tictactoe_Tiles,
			SIZEOF_16BIT(tictactoe_Tiles),1,1);
	
		// Setup the map for our image
		ham_bg[0].mi = ham_InitMapEmptySet(3,0);
		bg_one = ham_InitMapFragment((void *)tictactoe_Map,30,20,0,0,30,20,0);
		ham_InsertMapFragment(bg_one,0,0,0);
	
		// Display the background
		ham_InitBg(0,1,0,0);
	}
*/
	// After 50 VBLs, the next screen gets displayed
	if ((vbl_count > 50)) {
		start_screen_slide = 2; // Just in case		

		// Change the game state
		game_state = MAIN;
	}

	return;
} // End of TICTACTOE::start_screen_query_keys()


//*******************************************
// Function: TICTACTOE::start_screen_deinit()
// Purpose: Deinitialize the start screen
//*******************************************
void TICTACTOE::start_screen_deinit()
{
	// Deinitialize the background
	ham_DeInitBg(0);

	return;
} // End of TICTACTOE::start_screen_deinit()


//****************************************
// Function: TICTACTOE::main_screen_init()
// Purpose: Initialize the main screen
//****************************************
void TICTACTOE::main_screen_init()
{
	// "Players" option is "in focus"
	which = 0;

	// Set the object to visible
	visible = 1;

	// Start the VBL counter at 0
	vbl_count = 0;

	// Initialize the background and sprites palettes
	ham_LoadBGPal((void *)TitleScreen_Palette,256);
	ham_LoadObjPal((void *)objects_ms_Palette,256);
	// Setup the tileset for our image
	ham_bg[0].ti = ham_InitTileSet((void *)TitleScreen_Tiles,
		SIZEOF_16BIT(TitleScreen_Tiles),1,1);
	
	// Setup the map for our image
	ham_bg[0].mi = ham_InitMapEmptySet(3,0);
	bg_one = ham_InitMapFragment((void *)TitleScreen_Map,30,20,0,0,30,20,0);
	ham_InsertMapFragment(bg_one,0,0,0);
	ham_InitBg(0,1,0,0);
	return;
} // End of TICTACTOE::main_screen_init()


//**********************************************
// Function: TICTACTOE::main_screen_query_keys()
// Purpose: Gets input during main_screen()
//**********************************************
void TICTACTOE::main_screen_query_keys()
{
	if(anykey())
	{
		game_state = PLAY;
	}
	return;
} // End of TICTACTOE::main_screen_query_keys()


//******************************************
// Function: TICTACTOE::main_screen_deinit()
// Purpose: Deinitialize the main screen
//******************************************
void TICTACTOE::main_screen_deinit()
{
	ham_DeInitMixer();
	// Deinitialize the background and sprites
	ham_DeInitBg(0);
	
	// This must be called to actually delete the sprites
	ham_CopyObjToOAM();

	return;
} // End of TICTACTOE::main_screen_deinit()


//************************************
// Function: TICTACTOE::in_game_init()
// Purpose: Initialize game playing
//************************************
void TICTACTOE::in_game_init()
{
	// Start the VBL counter at 0
	vbl_count = 0;

	// Initialize the background and sprites palettes
	ham_LoadBGPal((void *)TileMap_Palette,256);
	ham_LoadObjPal((void *)objects_Palette,256);

	// Setup the tileset for our image
	ham_bg[0].ti = ham_InitTileSet((void *)TileMap_Tiles,
		SIZEOF_16BIT(TileMap_Tiles),1,1);
	
	// Setup the map for our image
	ham_bg[0].mi = ham_InitMapEmptySet(3,0);
	bg_one = ham_InitMapFragment((void *)TileMap_Map,30,20,0,0,30,20,0);
	ham_InsertMapFragment(bg_one,0,0,0);
	
	// Display the background
	ham_InitBg(0,1,3,0);
	
	return;
} // End of TICTACTOE::in_game_init()


//******************************************
// Function: TICTACTOE::in_game_query_keys()
// Purpose: Gets input during in_game()
//******************************************
void TICTACTOE::in_game_query_keys()
{
	// Increment the VBL counter every VBL
	++vbl_count;

	
	return;
} // End of TICTACTOE::in_game_query_keys()


//********************************************
// Function: TICTACTOE::in_game_redraw()
// Purpose: Redraw the screen during in_game()
//********************************************
void TICTACTOE::in_game_redraw()
{

} // End of TICTACTOE::in_game_redraw()


//**************************************
// Function: TICTACTOE::in_game_deinit()
// Purpose: Deinitialize game playing
//**************************************
void TICTACTOE::in_game_deinit()
{
	// Deinitialize the background and sprites
	ham_DeInitBg(0);
	

	// This must be called to actually delete the sprites
	ham_CopyObjToOAM();

	return;
} // End of TICTACTOE::in_game_deinit()

void TICTACTOE::level_two_init()
{
	// Start the VBL counter at 0
	vbl_count = 0;

	// Initialize the background and sprites palettes
	ham_LoadBGPal((void *)TileMap2_Palette,256);
	ham_LoadObjPal((void *)objects_Palette,256);

	// Setup the tileset for our image
	ham_bg[0].ti = ham_InitTileSet((void *)TileMap2_Tiles,
		SIZEOF_16BIT(TileMap2_Tiles),1,1);
	
	// Setup the map for our image
	ham_bg[0].mi = ham_InitMapEmptySet(3,0);
	bg_one = ham_InitMapFragment((void *)TileMap2_Map,30,20,0,0,30,20,0);
	ham_InsertMapFragment(bg_one,0,0,0);
	
	// Display the background
	ham_InitBg(0,1,3,0);
	
	return;

}
void TICTACTOE::level_two_deinit()
{
	// Deinitialize the background and sprites
	ham_DeInitBg(0);
	

	// This must be called to actually delete the sprites
	ham_CopyObjToOAM();
	return;
}

void TICTACTOE::level_three_init()
{
	// Start the VBL counter at 0
	vbl_count = 0;

	// Initialize the background and sprites palettes
	ham_LoadBGPal((void *)TileMap3_Palette,256);
	ham_LoadObjPal((void *)objects_Palette,256);

	// Setup the tileset for our image
	ham_bg[0].ti = ham_InitTileSet((void *)TileMap3_Tiles,
		SIZEOF_16BIT(TileMap3_Tiles),1,1);
	
	// Setup the map for our image
	ham_bg[0].mi = ham_InitMapEmptySet(3,0);
	bg_one = ham_InitMapFragment((void *)TileMap3_Map,30,20,0,0,30,20,0);
	ham_InsertMapFragment(bg_one,0,0,0);
	
	// Display the background
	ham_InitBg(0,1,3,0);
	
	return;

}
void TICTACTOE::level_three_deinit()
{
	// Deinitialize the background and sprites
	ham_DeInitBg(0);
	

	// This must be called to actually delete the sprites
	ham_CopyObjToOAM();
	return;
}

void TICTACTOE::level_four_init()
{

	// Start the VBL counter at 0
	vbl_count = 0;

	// Initialize the background and sprites palettes
	ham_LoadBGPal((void *)TileMap4_Palette,256);
	ham_LoadObjPal((void *)objects_Palette,256);

	// Setup the tileset for our image
	ham_bg[0].ti = ham_InitTileSet((void *)TileMap4_Tiles,
		SIZEOF_16BIT(TileMap4_Tiles),1,1);
	
	// Setup the map for our image
	ham_bg[0].mi = ham_InitMapEmptySet(3,0);
	bg_one = ham_InitMapFragment((void *)TileMap4_Map,30,20,0,0,30,20,0);
	ham_InsertMapFragment(bg_one,0,0,0);
	
	// Display the background
	ham_InitBg(0,1,3,0);
	
	return;

}
void TICTACTOE::level_four_deinit()
{
	// Deinitialize the background and sprites
	ham_DeInitBg(0);
	

	// This must be called to actually delete the sprites
	ham_CopyObjToOAM();
	return;
}
//***********************************
// Function: TICTACTOE::finish_init()
// Purpose: Displays the screen 
//          after tie, win or quit
//***********************************
void TICTACTOE::finish_init()
{
	// Start the VBL counter at 0
	vbl_count = 0;

	// Initialize the background palette
	ham_LoadBGPal((void *)GameOver_Palette,256);

	// Setup the tileset for our image
	ham_bg[0].ti = ham_InitTileSet((void *)GameOver_Tiles,
		SIZEOF_16BIT(GameOver_Tiles),1,1);
	// Setup the map for our image
	ham_bg[0].mi = ham_InitMapEmptySet(3,0);
	bg_one = ham_InitMapFragment((void *)GameOver_Map,30,20,0,0,30,20,0);
	ham_InsertMapFragment(bg_one,0,0,0);
	
	// Display the background
	ham_InitBg(0,1,0,0);

	return;
} // End of TICTACTOE::finish_init()


//*********************************************
// Function: TICTACTOE::finish_query_keys()
// Purpose: Gets input during the finish screen
//*********************************************
void TICTACTOE::finish_query_keys()
{
	// Increment the VBL counter every VBL
	++vbl_count;

	// Wait for the user to press a key
	if (vbl_count > 10 && anykey()) {
		game_state = MAIN;
	}

	return;
} // End of finish_query_keys()


//*************************************
// Function: TICTACTOE::finish_deinit()
// Purpose: Deinitialize finish()
//*************************************
void TICTACTOE::finish_deinit()
{
	// Deinitialize the background and sprites
	ham_DeInitBg(0);

	return;
} // End of TICTACTOE::finish_deinit()


//********************************************
// Function: TICTACTOE::square()
// Purpose: Converts co-ords to board[] number
//********************************************
u8 TICTACTOE::square(u8 x, u8 y)
{
	if (x == 8 && y == 8) return 0;
	if (x == 63 && y == 8) return 1;
	if (x == 119 && y == 8) return 2;
	if (x == 8 && y == 63) return 3;
	if (x == 63 && y == 63) return 4;
	if (x == 119 && y == 63) return 5;
	if (x == 8 && y == 119) return 6;
	if (x == 63 && y == 119) return 7;
	if (x == 119 && y == 119) return 8;

	return 9; // Passed a bad number (or two)
} // End of TICTACTOE::square()


//***************************************************
// Function: TICTACTOE::who()
// Purpose: Returns 0 = unocc, 1 = P1, 2 = P2
//***************************************************
u8 TICTACTOE::who(u8 square)
{
	return board[square];

} // End of TICTACTOE::who()


//*********************************************
// Function: TICTACTOE::is_winner()
// Purpose: Checks to see if there was a winner
//*********************************************
bool TICTACTOE::is_winner()
{
	if (board[0] != 0 && board[0] == board[1] && board[0] == board[2]) {
		winner = board[0];
		return true;
	} else if (board[3] != 0 && board[3] == board[4] && board[3] == board[5]) {
		winner = board[3];
		return true;
	} else if (board[6] != 0 && board[6] == board[7] && board[6] == board[8]) {
		winner = board[6];
		return true;
	} else if (board[0] != 0 && board[0] == board[3] && board[0] == board[6]) {
		winner = board[0];
		return true;
	} else if (board[1] != 0 && board[1] == board[4] && board[1] == board[7]) {
		winner = board[1];
		return true;
	} else if (board[2] != 0 && board[2] == board[5] && board[2] == board[8]) {
		winner = board[2];
		return true;
	} else if (board[0] != 0 && board[0] == board[4] && board[0] == board[8]) {
		winner = board[0];
		return true;
	} else if (board[2] != 0 && board[2] == board[4] && board[2] == board[6]) {
		winner = board[2];
		return true;
	}

	return false;
} // End of TICTACTOE::is_winner()


//****************************
// Function: TICTACTOE::gs()
// Purpose: Returns game_state
//****************************
TICTACTOE::states TICTACTOE::gs()
{
	return game_state;
} // End of TICTACTOE::gs()


//**************************
// Function: TICTACTOE::gt()
// Purpose: Returns turn
//**************************
u8 TICTACTOE::gt()
{
	return turn;
} // End of TICTACTOE::gt()


//******************************
// Function: TICTACTOE::gos()
// Purpose: Returns open_squares
//******************************
u8 TICTACTOE::gos() 
{
	return open_squares;
} // End of TICTACTOE::gos()


//**************************
// Function: TICTACTOE::gw()
// Purpose: Returns winner
//**************************
u8 TICTACTOE::gw()
{
	return winner;
} // End of TICTACTOE::gw()


//************************************************
// Function: TICTACTOE::check_samples()
// Purpose: Make sure the correct music is playing
//************************************************
void TICTACTOE::check_samples()
{
	if ((game_state == START) && (start_screen_slide == 0)) {
		if(!mysample[1]->playing) ham_PlaySample(mysample[1]);
	} else if (game_state == MAIN || game_state == PLAY || game_state == FINISH || game_state == LEVELTWO || game_state == LEVELTHREE || game_state == LEVELFOUR) {
		if(!mysample[0]->playing) ham_PlaySample(mysample[0]);
	}

	return;
} // End of TICTACTOE::check_samples()


//************************************
// Function: anykey()
// Purpose: True if any key is pressed
//************************************
bool anykey()
{
	return (F_CTRLINPUT_DOWN_PRESSED || F_CTRLINPUT_LEFT_PRESSED || F_CTRLINPUT_A_PRESSED ||
		F_CTRLINPUT_UP_PRESSED || F_CTRLINPUT_RIGHT_PRESSED || F_CTRLINPUT_B_PRESSED ||
		F_CTRLINPUT_START_PRESSED || F_CTRLINPUT_SELECT_PRESSED);
} // End of anykey()
