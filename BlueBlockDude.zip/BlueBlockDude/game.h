//**************************
// Filename: game.h
// Author: Aaron Rogers
// Updated: 09/04/02
// Purpose: Tic Tac Toe game
//**************************

#ifndef GAME_H
#define GAME_H

// Library Includes
#include "mygba.h"
#include "gfx/player.pal.c"
#include "gfx/player.raw.c"
#include "gfx/player.map.c"
#include "gfx/enemy.pal.c"
#include "gfx/enemy.raw.c"
#include "gfx/enemy.map.c"
#include "gfx/bullet.pal.c"
#include "gfx/bullet.raw.c"
#include "gfx/bullet.map.c"
#include "gfx/TileMap.pal.c"
#include "gfx/TileMap.raw.c"
#include "gfx/TileMap.map.c"
#include "gfx/TileMap2.pal.c"
#include "gfx/TileMap2.raw.c"
#include "gfx/TileMap2.map.c"
#include "gfx/SpikeTile.pal.c"
#include "gfx/SpikeTile.raw.c"
#include "gfx/SpikeTile.map.c"
#include "gfx/GroundTile.pal.c"
#include "gfx/GroundTile.raw.c"
#include "gfx/GroundTile.map.c"
#include "gfx/DoorTile.pal.c"
#include "gfx/DoorTile.raw.c"
#include "gfx/DoorTile.map.c"
#include "gfx/BlankMap.pal.c"
#include "gfx/BlankMap.raw.c"
#include "gfx/BlankMap.map.c"
#include "gfx/TileMap5.pal.c"
#include "gfx/TileMap5.raw.c"
#include "gfx/TileMap5.map.c"
#include "gfx/TileMap6.pal.c"
#include "gfx/TileMap6.raw.c"
#include "gfx/TileMap6.map.c"
#include "gfx/GameOver.pal.c"
#include "gfx/GameOver.raw.c"
#include "gfx/GameOver.map.c"
#include "gfx/SplashScreen.pal.c"
#include "gfx/SplashScreen.raw.c"
#include "gfx/SplashScreen.map.c"
#include "gfx/TitleScreen.pal.c"
#include "gfx/TitleScreen.raw.c"
#include "gfx/TitleScreen.map.c"
// Pointers to sample data
extern const WaveData _binary_clip_raw_start;
extern const WaveData _binary_dong_raw_start;

// Game Winner
#define NO_WINNER 0;
#define PLAYER1   1;
#define PLAYER2   2;


// Struct used for mouse pointers & squares on the board
struct Object
{
	u8 x_pos; // X-Position of the Object
	u8 y_pos; // Y-Position of the Object
	u8 image; // Holds the image for the Object *** wrong, obj num ***
};


class TICTACTOE
{
public:
	// Game States: 0     1     2       3       4     5
	enum states {START, MAIN, PLAY,LEVELTWO, LEVELTHREE, LEVELFOUR, FINISH, OPTION, QUIT};
	
	// Default Constructor
	TICTACTOE();

	// Functions
	void init(); // Initialize the game

	// START functions
	void start_screen_init(); // Initialize the start screen
	void start_screen_query_keys(); // Check for input
	void start_screen_deinit(); // Deinitialize the start screen

	// MAIN functions
	void main_screen_init(); // Initialize the main screen
	void main_screen_query_keys(); // Check for input
	void main_screen_deinit(); // Deinitialize the main screen
	
	// PLAY functions
	void in_game_init(); // Initialize game playing
	void in_game_query_keys(); // Check for input
	void in_game_redraw(); // Update sprites
	void in_game_deinit(); // Deinitialize game playing

	void level_two_init();
	void level_two_deinit();

	void level_three_init();
	void level_three_deinit();

	void level_four_init();
	void level_four_deinit();

	// FINISH functions
	void finish_init(); // Initialize the end of a game
	void finish_query_keys(); // Check for input
	void finish_deinit(); // Deitialize the end of a game
	
	// Other functions
	u8 square(u8 x, u8 y); // Converts co-ords to board[] number
	u8 who(u8 square); // Returns who is occupying a square
	bool is_winner(); // Checks to see if there was a winner
	states gs(); // Returns 'game_state'
	u8 gt(); // Returns 'turn'
	u8 gos(); // Returns 'open_squares'
	u8 gw(); // Returns 'winner'

	// Sound functions
	void check_samples();

	states game_state; // Current game state
private:
	// Variables
	u8 start_screen_slide; // The current start screen slide	
	u8 turn;  // Current turn, 1 = Player 1, 2 = Player 2
	u8 winner;  // The game winner, 0 = No one, 1 = P1, 2 = P2
	u8 open_squares;  // Number of unoccupied squares
	u8 players; // Number of players
	u8 skill; // 1 = novice ... 5 = expert
	u32 vbl_count;  // Keeps track of how many VBLs have passed
	u8 us; // Updated square, 0 - 8
	u8 which; // Which option is "in focus"
	u8 visible; // Is the sprite visible or not
	u8 board[9]; // The playing field. 0 = empty, 1 = P1, 2 = P2
	map_fragment_info_ptr bg_one; // Used for one BG in any function
	u32 mixer_freq; // Mixer frequency
	sample_info *mysample[3]; // Sounds

	// *** may be able to use only one or two pointers again ***
	Object num_play_pnt; // Used for number of players sprite
	Object skill_pnt; // Used for the skill level sprite
	Object my_pointer; // Used as a "mouse"
	Object spots[9]; // Sprite is activated when someone moves there

}; // End of class TICTACTOE


// Other Functions
bool anykey();


#endif
