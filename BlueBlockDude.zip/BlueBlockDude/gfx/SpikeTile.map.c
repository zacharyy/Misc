/*
 * 1x1 map data
 */
const unsigned short SpikeTile_Map[1] = {
0x0000
};

