/*
 * 1x1 map data
 */
const unsigned short WeaponUpgrade_Map[1] = {
0x0000
};

