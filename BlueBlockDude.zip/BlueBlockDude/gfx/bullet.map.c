/*
 * 1x1 map data
 */
const unsigned short bullet_Map[1] = {
0x0000
};

