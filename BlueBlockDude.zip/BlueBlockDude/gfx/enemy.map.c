/*
 * 1x1 map data
 */
const unsigned short Enemy_Map[1] = {
0x0000
};

