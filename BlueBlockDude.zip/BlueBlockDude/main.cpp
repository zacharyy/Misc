//**************************
// Filename: main.cpp
// Author: Aaron Rogers
// Updated: 09/04/02
// Purpose: Tic Tac Toe game
//**************************

// Library Includes
#include "game.h"
#include"gfx/WeaponUpgrade.raw.c"
#include"gfx/WeaponUpgrade.map.c"
u8 player;         // Sprite object number of the block
int jump = 0;
int direction = 1;
int blankTile = 0x0004;
int doorTile = 0x0001;
int groundTile = 0x0003;
int spikeTile = 0x0000;
u8 player_x = 8;  // X position of block (column)
u8 player_y = 8;   // Y position of block (row)
bool playerCreated = false;
u8 vbl_count = 0; // Keeps track of the number of VBLs
bool playerMovingRight = true;
unsigned short *currentMap;

// Enemy Stuff
u8 enemy_x = 100;
u8 enemy_y = 144;
u8 enemy;
bool enemyDestroyed = false;
int enemyDirection = 1;
int enemyDirection2 = 1;
int enemy_health = 5;
void update_enemy();

// Item Stuff
u8 item_x = 100;
u8 item_y = 144;
u8 item;
bool itemPickedUp = false;

// Bullet Stuff
u8 bullet_x;
u8 bullet_y;
u8 bullet;
bool bulletDestroyed = true;
int bulletDir = 0;
bool bulletCanMove;
int bulletDamage = 1;
// Door Location
u8 door_x;
u8 door_y;

// Function prototypes
void start_screen_vbl_func(); // start screen VBL function
void main_screen_vbl_func(); // main screen VBL function
void in_game_vbl_func(); // in game VBL function
void finish_vbl_func(); // finish VBL function
void level2_vbl_func();
void level3_vbl_func();
void level4_vbl_func();

// Global Variables
TICTACTOE game; // The main game object of the TICTACTOE class
bool newframe = FALSE; // Used for playing sound to keep track of new frames


bool CanMoveRight()
{

    if(currentMap[(30*(player_y)/8 + (player_x)/8) + 1] != (blankTile) || player_x >= 224)
        return false;
    return true;
}


bool CanMoveLeft()
{

    if(currentMap[30*(player_y)/8 + (player_x-1)/8] != (blankTile) || player_x <= 8)
       return false;
    return true;
}

bool CanJump()
{
    if(currentMap[30*(player_y/8+1) + player_x/8] == (blankTile))
        return false;
    return true;
}
bool CanMoveUp()
{
    if(currentMap[30*(player_y/8) + player_x/8] != (blankTile))
        return false;
    else if(currentMap[30*(player_y/8) + (player_x+7)/8] != (blankTile))
	return false;
    return true;
}
bool CanFall()
{
    if(currentMap[30*(player_y/8 + 1) + player_x/8] != (blankTile))
        return false;
    else if(currentMap[30*(player_y/8 + 1) + (player_x+7)/8] != (blankTile))
	return false;
    return true;
}
bool BulletCanMove()
{
    if(currentMap[bullet_y/8*30 + bullet_x/8] != blankTile)
        return false;
    return true;
}
void update_boss()
{
    if(!enemyDestroyed)
    {
    if(enemy_x <= 8)
    {
        enemyDirection = 1;
    }
    else if(enemy_x >= 232)
    {
        enemyDirection = -1;
    }
    if(enemy_y >= 152)
    {
        enemyDirection2 = -1;
    }
    if(enemy_y <= 8)
    {
        enemyDirection2 = 1;
    }
    if((enemy_x - bullet_x)/8 == 0 && (enemy_y - bullet_y)/8 == 0 && !bulletDestroyed)
    {
	enemy_health -= bulletDamage;
         bulletDestroyed = true;
         ham_DeleteObj(bullet);
	if(enemy_health <= 0)
	{
         enemyDestroyed = true;
         ham_DeleteObj(enemy);
	}   
    }
    if((enemy_x - player_x)/8 == 0 && (enemy_y - player_y)/8 == 0)
    {
        ham_DeleteObj(enemy);
	game.game_state = TICTACTOE::FINISH;
	if(!itemPickedUp)
	{
		itemPickedUp = true;
		ham_DeleteObj(item);
	}
    }
    enemy_x += enemyDirection;
    enemy_y += enemyDirection2;
    ham_SetObjX(enemy, enemy_x);
    ham_SetObjY(enemy, enemy_y);
    }

}
void query_buttons()
{
    if(F_CTRLINPUT_SELECT_PRESSED)
    {
	if(!itemPickedUp)
	{
		itemPickedUp = true;
		ham_DeleteObj(item);
	}	
	if(!enemyDestroyed)
		ham_DeleteObj(enemy);
	if(!bulletDestroyed)
	{
		bulletDestroyed = true;
		ham_DeleteObj(bullet);
	}
	/*if(playerCreated)
	{
		playerCreated = false;
		ham_DeleteObj(player);
	}*/
	game.game_state = TICTACTOE::START;
    }
    if(F_CTRLINPUT_A_PRESSED && CanJump())
    {
        jump = 12;
    }

    if(F_CTRLINPUT_DOWN_PRESSED)
    {
        //if (block_y < 200) block_y++;
        //player_y++;
    }

    if(F_CTRLINPUT_LEFT_PRESSED && CanMoveLeft())
    {
        player_x -= 2;
        playerMovingRight = false;
    }

    if(F_CTRLINPUT_RIGHT_PRESSED && CanMoveRight())
    {
        player_x += 2;
        playerMovingRight = true;
    }
    if(F_CTRLINPUT_R_PRESSED && bulletDestroyed)
    {
	if(playerMovingRight)
        	bulletDir = 1;
	else
		bulletDir = -1;
        bulletDestroyed = false;        
        bullet = ham_CreateObj((void*)bullet_Tiles,
        	0,0,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,
        	player_x,player_y);

        bullet_x = player_x;
        bullet_y = player_y;
    }
    else if(F_CTRLINPUT_L_PRESSED && bulletDestroyed)
    {
	if(playerMovingRight)
        	bulletDir = 1;
	else
		bulletDir = -1;
        bulletDestroyed = false;        
        bullet = ham_CreateObj((void*)bullet_Tiles,
        	0,0,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,
        	player_x,player_y);

        bullet_x = player_x;
        bullet_y = player_y;
    }
    if(F_CTRLINPUT_B_PRESSED && enemyDestroyed && vbl_count > 10)
    {
	//game.game_state = TICTACTOE::states(++((int)game.game_state));
	//vbl_count = 0;
    }
    if((door_x - player_x)/8 == 0 && (door_y - player_y)/8 == 0 && enemyDestroyed)
    {
	game.game_state = TICTACTOE::states(++((int)game.game_state));
		//ham_DeInitBg(0);
            //loadNextLevel();
            //CanGoNext = false;
    }
    if(currentMap[(30*((player_y+8)/8) + player_x/8)] == spikeTile)
    {
	if(!itemPickedUp)
	{
		itemPickedUp = true;
		ham_DeleteObj(item);
	}	
	if(!enemyDestroyed)
		ham_DeleteObj(enemy);
	game.game_state = TICTACTOE::FINISH;
    }
    return;
} // End of query_buttons()

void weapon_pickup()
{
	if((player_x - item_x)/8 == 0 && (player_y - item_y)/8 == 0 && !itemPickedUp)
	{
		itemPickedUp = true;
		bulletDamage = 3;
		ham_DeleteObj(item);
	}
}
void move_player()
{
    for(int i = 0; i < 2; i++)
    {
        if(jump > 0 && CanMoveUp())
        {
            player_y -= 1;
            if(i == 1) jump--;
        }
        else if (CanFall())
        {
            jump = 0;
            player_y++;
        }
    }

	if(!BulletCanMove() && !bulletDestroyed)
        {
            ham_DeleteObj(bullet);
            bulletDestroyed = true;
            bullet_x = 0;
            bullet_y = 0;
        }
        else
        {
            bullet_x += 2*bulletDir;
        }
 
     return;

} // End of move_block()

void update_player()
{
    ham_SetObjX(player,player_x);
    ham_SetObjY(player,player_y);

    if(!bulletDestroyed)
    {
        ham_SetObjX(bullet,bullet_x);
        ham_SetObjY(bullet,bullet_y);
    }

    return;
} // End of update_block()*/
void update_enemy()
{
    if(!enemyDestroyed)
    {
    if(currentMap[30*enemy_y/8 + enemy_x/8] != blankTile)
    {
        enemyDirection = 1;
    }
    else if(currentMap[enemy_y/8*30 + enemy_x/8+1] != blankTile && enemyDirection == 1)
    {
        enemyDirection = -1;
    }
    if((enemy_x - bullet_x)/8 == 0 && (enemy_y - bullet_y)/8 == 0 && !bulletDestroyed)
    {
	enemy_health -= bulletDamage;
         bulletDestroyed = true;
         ham_DeleteObj(bullet);
	if(enemy_health <= 0)
	{
         enemyDestroyed = true;
         ham_DeleteObj(enemy);
	}   
    }
    if((enemy_x - player_x)/8 == 0 && (enemy_y - player_y)/8 == 0)
    {
        ham_DeleteObj(enemy);
	game.game_state = TICTACTOE::FINISH;
	if(!itemPickedUp)
	{
		itemPickedUp = true;
		ham_DeleteObj(item);
	}
    }
    enemy_x += enemyDirection;
    ham_SetObjX(enemy, enemy_x);
    ham_SetObjY(enemy, enemy_y);
    }
}
//*************************************
// Function: main()
// Purpose: The starting point for the 
//   Tic Tac Toe game.  A new game is 
//   created, initialized and controled 
//   by the VBL functions
//*************************************
int main()
{
	// Seed the random function
	srand(F_VCNT_CURRENT_SCANLINE);

	// Initialize the game
	game.init();

	// Here's the main game state loop.  As long as the 
	// game state isn't set to QUIT, keep looping
	game.game_state = TICTACTOE::START;
	while (game.gs() != TICTACTOE::QUIT)
	{
		vbl_count = 0;
		enemyDestroyed = false;
		// Each loop, check the game state and react accordingly
		switch(game.gs())
		{
		case TICTACTOE::START:
			// Initialize the start screen
			game.start_screen_init();

			// Start the VBL interrupt handler
			ham_StartIntHandler(INT_TYPE_VBL,(void*)&start_screen_vbl_func);

			// Loop while we are still at the start screen
			while(game.gs() == TICTACTOE::START) {
				if(newframe) {
					// Update the mixer once per frame
					ham_UpdateMixer();
					// Make sure the sounds are playing
					game.check_samples();
					// Reset newframe
					newframe = FALSE;
				}
			}

			// At this point the start screen is over
			// Clean up after the start screen
			game.start_screen_deinit();

			// Stop the VBL interrupt handler
			ham_StopIntHandler(INT_TYPE_VBL);
			
			break;
		case TICTACTOE::MAIN:
			// Initialize the main screen
			game.main_screen_init();

			// Start the VBL interrupt handler
			ham_StartIntHandler(INT_TYPE_VBL,(void*)&main_screen_vbl_func);

			// Loop while we are still at the main screen
			while(game.gs() == TICTACTOE::MAIN) {
				if(newframe) {
					// Update the mixer once per frame
					ham_UpdateMixer();
					// Make sure the sounds are playing
					game.check_samples();
					// Reset newframe
					newframe = FALSE;
				}
			}

			// At this point the main screen is over
			// Clean up after the main screen
			game.main_screen_deinit();

			// Stop the VBL interrupt handler
			ham_StopIntHandler(INT_TYPE_VBL);
			
			break;
		case TICTACTOE::PLAY:
			// Initialize the game loop
			player_x = 8;
			player_y = 140;
			door_x = 224;
			door_y = 120;
			enemy_x = 100;
			enemy_y = 144;
			enemy_health = 3;
			bulletDamage = 1;
			if(!playerCreated)
				player = ham_CreateObj((void*)Player_Tiles,
        				0,0,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,
        				player_x,player_y);
			playerCreated = true;
			enemy = ham_CreateObj((void*)Enemy_Tiles,
        			0,0,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,
        			enemy_x,enemy_y);
			game.in_game_init();
			currentMap = (unsigned short *)TileMap_Map;
			// Start the VBL interrupt handler
			ham_StartIntHandler(INT_TYPE_VBL,(void*)&in_game_vbl_func);

			// Loop while we are still playing the game
			while(game.gs() == TICTACTOE::PLAY) {
				if(newframe) {
					// Update the mixer once per frame
					ham_UpdateMixer();
					// Make sure the sounds are playing
					game.check_samples();
					// Reset newframe
					newframe = FALSE;
				}
			}

			// At this point the game is over
			// Clean up after the game loop
			game.in_game_deinit();

			// Stop the VBL interrupt handler
			ham_StopIntHandler(INT_TYPE_VBL);

			break;
		case TICTACTOE::FINISH:
			// Initialize the finish screen loop
			game.finish_init();

			// Start the VBL interrupt handler
			ham_StartIntHandler(INT_TYPE_VBL,(void*)&finish_vbl_func);
			
			// Loop while we are still at the finish screen
			while(game.gs() == TICTACTOE::FINISH) {
				if(newframe) {
					// Update the mixer once per frame
					ham_UpdateMixer();
					// Make sure the sounds are playing
					game.check_samples();
					// Swap newframe
					newframe = FALSE;
				}
			}

			// Clean up after the finish screen
			game.finish_deinit();

			// Stop the VBL interrupt handler
			ham_StopIntHandler(INT_TYPE_VBL);

			break;
		case TICTACTOE::LEVELTWO:
			// Initialize the game loop
			game.level_two_init();
			door_x = 224;
			door_y = 136;
			enemy_x = 160;
			enemy_y = 144;
			enemy_health = 3;
			enemy = ham_CreateObj((void*)Enemy_Tiles,
        			0,0,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,
        			enemy_x,enemy_y);
			currentMap = (unsigned short *)TileMap2_Map;
			player_x = 8;
			player_y = 8;
			item_x = 224;
			item_y = 88;
			item = ham_CreateObj((void*)WeaponUpgrade_Tiles,
        			0,0,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,
        			item_x,item_y);
			itemPickedUp = false;
			// Start the VBL interrupt handler
			ham_StartIntHandler(INT_TYPE_VBL,(void*)&level2_vbl_func);

			// Loop while we are still playing the game
			while(game.gs() == TICTACTOE::LEVELTWO) {
				if(newframe) {
					// Update the mixer once per frame
					ham_UpdateMixer();
					// Make sure the sounds are playing
					game.check_samples();
					// Reset newframe
					newframe = FALSE;
				}
			}

			// At this point the game is over
			// Clean up after the game loop
			if(!itemPickedUp) ham_DeleteObj(item);
			game.level_two_deinit();

			// Stop the VBL interrupt handler
			ham_StopIntHandler(INT_TYPE_VBL);
			break;
		case TICTACTOE::LEVELTHREE:
			// Initialize the game loop
			door_x = 172;
			door_y = 144;
			enemy_x = 50;
			enemy_y = 112;
			enemy_health = 3;
			enemy = ham_CreateObj((void*)Enemy_Tiles,
        			0,0,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,
        			enemy_x,enemy_y);
			game.level_three_init();
			player_x = 8;
			player_y = 140;
			currentMap = (unsigned short *)TileMap3_Map;
			// Start the VBL interrupt handler
			ham_StartIntHandler(INT_TYPE_VBL,(void*)&level3_vbl_func);

			// Loop while we are still playing the game
			while(game.gs() == TICTACTOE::LEVELTHREE) {
				if(newframe) {
					// Update the mixer once per frame
					ham_UpdateMixer();
					// Make sure the sounds are playing
					game.check_samples();
					// Reset newframe
					newframe = FALSE;
				}
			}

			// At this point the game is over
			// Clean up after the game loop
			game.level_three_deinit();
			// Stop the VBL interrupt handler
			ham_StopIntHandler(INT_TYPE_VBL);
			break;
		case TICTACTOE::LEVELFOUR:
			// Initialize the game loop
			game.level_four_init();
			currentMap = (unsigned short *)TileMap4_Map;
			// Start the VBL interrupt handler
			player_x = 8;
			player_y = 140;
			enemy_x = 80;
			enemy_y = 8;
			enemy_health = 12;
			enemy = ham_CreateObj((void*)Enemy_Tiles,
        			0,0,OBJ_MODE_NORMAL,1,0,0,0,0,0,0,
        			enemy_x,enemy_y);
			ham_StartIntHandler(INT_TYPE_VBL,(void*)&level4_vbl_func);

			// Loop while we are still playing the game
			while(game.gs() == TICTACTOE::LEVELFOUR) {
				if(newframe) {
					// Update the mixer once per frame
					ham_UpdateMixer();
					// Make sure the sounds are playing
					game.check_samples();
					// Reset newframe
					newframe = FALSE;
				}
			}

			// At this point the game is over
			// Clean up after the game loop
			game.level_four_deinit();

			// Stop the VBL interrupt handler
			ham_StopIntHandler(INT_TYPE_VBL);
			break;
		case TICTACTOE::OPTION:
			break;
		case TICTACTOE::QUIT:
			break;
		default: // This should never happen
			break;
		}

	} // End of while(game_state != QUIT)

	return 0;
} // End of main()


//*************************************
// Function: start_screen_vbl_func()
// Purpose: Handles control of the game
//          during the start screen
//*************************************
void start_screen_vbl_func()
{
	// Sync the mixer at the beginning of the VBL
	ham_SyncMixer();

	// Check for keypad input
	game.start_screen_query_keys();

	// Set newframe to true once per frame
	newframe = TRUE;

	return;
} // End of start_screen_vbl_func()


//*************************************
// Function: main_screen_vbl_func()
// Purpose: Handles control of the game
//          during the main screen
//*************************************
void main_screen_vbl_func()
{
	// Sync the mixer at the beginning of the VBL
	ham_SyncMixer();

	// Update sprites
	ham_CopyObjToOAM();

	// Check for keypad input
	game.main_screen_query_keys();

	// Set newframe to true once per frame
	newframe = TRUE;

	return;
} // End of main_screen_vbl_func()


//********************************
// Function: in_game_vbl_func()
// Purpose: Handles control of the 
//          game during play
//********************************
void in_game_vbl_func()
{
	vbl_count++;
	//ham_SyncMixer();
    // Copy block sprite to hardware
    ham_CopyObjToOAM();
	
    // Process the following every VBL
    query_buttons(); // Query for input
    move_player();
    update_player();
    update_enemy();
	//newframe = TRUE;
    //update_boss();

	return;
} // End of in_game_vbl_func()
void level2_vbl_func()
{
	vbl_count++;
	//ham_SyncMixer();
    // Copy block sprite to hardware
    ham_CopyObjToOAM();
	
    // Process the following every VBL
    query_buttons(); // Query for input
    move_player();
    update_player();
    update_enemy();
	weapon_pickup();
	//newframe = TRUE;
    //update_boss();

}
void level3_vbl_func()
{
	vbl_count++;
	//ham_SyncMixer();
    // Copy block sprite to hardware
    ham_CopyObjToOAM();
	
    // Process the following every VBL
    query_buttons(); // Query for input
    move_player();
    update_player();
    update_enemy();
	//newframe = TRUE;
    //update_boss();

}
void level4_vbl_func()
{
	vbl_count++;
	//ham_SyncMixer();
    // Copy block sprite to hardware
    ham_CopyObjToOAM();
	
    // Process the following every VBL
    query_buttons(); // Query for input
    move_player();
    update_player();
    //update_enemy();
	//newframe = TRUE;
    update_boss();

}
//*************************************
// Function: finish_vbl_func()
// Purpose: Handles control of the game
//          during the finish screen
//*************************************
void finish_vbl_func()
{
	vbl_count++;
	// Sync the mixer at the beginning of the VBL
	//ham_SyncMixer();

	// Update sprites
	ham_CopyObjToOAM();

	// Check for keypad input
	game.finish_query_keys();

	// Set newframe to true once per frame
	//newframe = TRUE;

	return;
} // End of finish_vbl_func()
